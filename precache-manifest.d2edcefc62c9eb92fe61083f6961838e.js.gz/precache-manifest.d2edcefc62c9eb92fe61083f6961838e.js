self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8e84e4de5cdd5804854f839d35456b95",
    "url": "/GameAnalytics.min.js"
  },
  {
    "revision": "8cb6fea73991cc41633515762fd7236e",
    "url": "/download.png"
  },
  {
    "revision": "22a1385cb2de8dbdacfa702376553e5d",
    "url": "/download1.html"
  },
  {
    "revision": "fd451fff97af9a22c9618acacd47cf46",
    "url": "/icon-default-dark.png"
  },
  {
    "revision": "8539a6bf2ecb0e3559784b3af5a25fb4",
    "url": "/icon-default-dark2.png"
  },
  {
    "revision": "75f6e9a0019cdd5252d2925b4a9acd52",
    "url": "/icon-default-old.png"
  },
  {
    "revision": "9e4c687f3242d4bb2e9bd22d292ae368",
    "url": "/icon-default.png"
  },
  {
    "revision": "4ebadc7855a4dbc4f3f80e5e77643c32",
    "url": "/icon-inscription-default.png"
  },
  {
    "revision": "fb1d97b0b59b99fcc61f1fbe294362cd",
    "url": "/index.html"
  },
  {
    "revision": "5a96d0ba187899d2912fbefbd0b052bb",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "0c44a65ec62b95e32dd9a75fb959fead",
    "url": "/signal.mp3"
  },
  {
    "revision": "a2781ede6c45dfccd59f",
    "url": "/static/css/Alert.798543c0.css"
  },
  {
    "revision": "3648ec28504e8bd3897c",
    "url": "/static/css/Balance.a822845a.css"
  },
  {
    "revision": "6f1dac2f14fe68aa6046",
    "url": "/static/css/Bownload.99287f45.css"
  },
  {
    "revision": "71d9c608bcc9835bb108",
    "url": "/static/css/Brc20.39289a05.css"
  },
  {
    "revision": "815715f5e9f610db27ab",
    "url": "/static/css/CVAirdrop.0ae92564.css"
  },
  {
    "revision": "ff3f09c2b2454455286f",
    "url": "/static/css/Chat.77a7e761.css"
  },
  {
    "revision": "6354534e0676c3d3b226",
    "url": "/static/css/ChatBanned.dc6b0893.css"
  },
  {
    "revision": "80fd096549012f511c8e",
    "url": "/static/css/ChatBurn.81c3a972.css"
  },
  {
    "revision": "b9d3ba752e2ebb12d514",
    "url": "/static/css/ChatIndex.4cf49718.css"
  },
  {
    "revision": "3ab004fcb041cc4fd51f",
    "url": "/static/css/ChatNewPayment.e2eaeb73.css"
  },
  {
    "revision": "c752b26426b8883eed48",
    "url": "/static/css/ChatOfficial.9f960e54.css"
  },
  {
    "revision": "48542e4bf5bd796a1577",
    "url": "/static/css/ChatPenalty.cd21d9d4.css"
  },
  {
    "revision": "c38a46ef114b30b6d438",
    "url": "/static/css/ChatSet.88ec35dc.css"
  },
  {
    "revision": "5f2d2e076750b3bd34b5",
    "url": "/static/css/ChatTop.30f30f9c.css"
  },
  {
    "revision": "1a49df09446764497362",
    "url": "/static/css/Chat~ChatTop.8139dc0b.css"
  },
  {
    "revision": "b2f74db4eeb8e256c286",
    "url": "/static/css/Check.d0f096ee.css"
  },
  {
    "revision": "2c7dc569fabb921becc1",
    "url": "/static/css/Connect.2d5a5fed.css"
  },
  {
    "revision": "cdd080abac81355252e9",
    "url": "/static/css/Discover.69d99947.css"
  },
  {
    "revision": "dbfb18ec61cf31b823b1",
    "url": "/static/css/Evm.dd10dc97.css"
  },
  {
    "revision": "97156c90daca05536956",
    "url": "/static/css/Fav.cddc864a.css"
  },
  {
    "revision": "a38951520e75bbc72437",
    "url": "/static/css/FavoriteManage.e992aa7b.css"
  },
  {
    "revision": "e186001a2c2a991c40af",
    "url": "/static/css/Gas.97b043d0.css"
  },
  {
    "revision": "061b58df85badc927e99",
    "url": "/static/css/Home.05bcd2e9.css"
  },
  {
    "revision": "9eae1c024f2f321eda45",
    "url": "/static/css/Inscription.1f7f2157.css"
  },
  {
    "revision": "6c22db96184564069125",
    "url": "/static/css/Invitation.2d89d402.css"
  },
  {
    "revision": "ded15d9ecdd96d6ea4d4",
    "url": "/static/css/Login.b99c9631.css"
  },
  {
    "revision": "14f87346d050155ed027",
    "url": "/static/css/Market.e0eed4ed.css"
  },
  {
    "revision": "0ae9e9307130591ad243",
    "url": "/static/css/Me.857c247f.css"
  },
  {
    "revision": "59752582401afc36dabc",
    "url": "/static/css/MyChats.541d7202.css"
  },
  {
    "revision": "f7427158066b77e7115d",
    "url": "/static/css/NFT.9deb2a31.css"
  },
  {
    "revision": "e8619bbae9e72457fa57",
    "url": "/static/css/Notice.a6ab9ac8.css"
  },
  {
    "revision": "095c754cb549668c9f07",
    "url": "/static/css/OfficialVerification.3be2b2a1.css"
  },
  {
    "revision": "8aca776a180e45121f52",
    "url": "/static/css/Perp.d9fd99a3.css"
  },
  {
    "revision": "956f3b92ec0d2b17a443",
    "url": "/static/css/Plate.6b34ec3d.css"
  },
  {
    "revision": "d3fc20d8973150204506",
    "url": "/static/css/Pool.01d22146.css"
  },
  {
    "revision": "167e0204cc04d682ebdc",
    "url": "/static/css/RedCreate.8ed141c4.css"
  },
  {
    "revision": "160803ad5aeaf30956b0",
    "url": "/static/css/RedRecord.07952493.css"
  },
  {
    "revision": "01da6cc13069418f6c1d",
    "url": "/static/css/Runes.72a8b80b.css"
  },
  {
    "revision": "e89d1554d847eeacb327",
    "url": "/static/css/ShareLink.4d862330.css"
  },
  {
    "revision": "d4d29261c95f6e9e62a2",
    "url": "/static/css/Token.99c66042.css"
  },
  {
    "revision": "435e3886be97847b8552",
    "url": "/static/css/UserInfo.c5e24d97.css"
  },
  {
    "revision": "cd366f84d7b0b4562882",
    "url": "/static/css/Wallet.24a43d2f.css"
  },
  {
    "revision": "be8a3239a639da8fb7c3",
    "url": "/static/css/WalletDetail.3feb6f0d.css"
  },
  {
    "revision": "7faaecaa7c708d2fb91a",
    "url": "/static/css/app.8dd97f34.css"
  },
  {
    "revision": "2a8d14332a6ab51b9af9",
    "url": "/static/css/chunk-commons.f4ac5b34.css"
  },
  {
    "revision": "cb4abbb7a4c21e0ca69f",
    "url": "/static/css/chunk-libs.132677af.css"
  },
  {
    "revision": "caca61b47349ec0636f6",
    "url": "/static/css/chunk-vant.cdb21971.css"
  },
  {
    "revision": "d15fadfac3096455d60b",
    "url": "/static/css/vendors~Check.02f6b728.css"
  },
  {
    "revision": "a9dee7b0be5a20b72315",
    "url": "/static/css/whaleTracking.becc3bd4.css"
  },
  {
    "revision": "1814de9403f8ab505e590ebd32af60d0",
    "url": "/static/fonts/iconfont.1814de94.ttf"
  },
  {
    "revision": "1c7bd28d1f4ef6709e45ac5446fbd6ed",
    "url": "/static/fonts/iconfont.1c7bd28d.woff2"
  },
  {
    "revision": "b06339359203fc4c85da0fc0ee470a58",
    "url": "/static/fonts/iconfont.b0633935.eot"
  },
  {
    "revision": "fa41907a24fb3c5aa2eedce5418b93ae",
    "url": "/static/fonts/iconfont.fa41907a.woff"
  },
  {
    "revision": "0415cf4ebd3976a0db17e2fa1e9812f6",
    "url": "/static/fonts/index.0415cf4e.eot"
  },
  {
    "revision": "87ee1a70c3af3cb1a4d8de1d96568fa0",
    "url": "/static/fonts/index.87ee1a70.woff"
  },
  {
    "revision": "abed1cb7ce7794b656c39076aaca6970",
    "url": "/static/fonts/index.abed1cb7.woff2"
  },
  {
    "revision": "de94a85c73334510b8645762a276917d",
    "url": "/static/fonts/index.de94a85c.ttf"
  },
  {
    "revision": "c2cea02547f4912de1c56978d638469c",
    "url": "/static/img/1.c2cea025.png"
  },
  {
    "revision": "a0c7411246a0fe27ced4b0215df7ff51",
    "url": "/static/img/2.a0c74112.png"
  },
  {
    "revision": "980df93c752c8ce347121c1adaaaef89",
    "url": "/static/img/3.980df93c.png"
  },
  {
    "revision": "c8b32dea8a6db7dbe69487e5ee135146",
    "url": "/static/img/ADD_LIQUIDITY.c8b32dea.svg"
  },
  {
    "revision": "11a65aa5235275cb27f849910128b93e",
    "url": "/static/img/AI.11a65aa5.svg"
  },
  {
    "revision": "9db07bc6528845a0c0f5f0b9aad2e6a4",
    "url": "/static/img/AllChains.9db07bc6.svg"
  },
  {
    "revision": "538d9a01a42e20c1722dab4b604e677f",
    "url": "/static/img/BURN.538d9a01.svg"
  },
  {
    "revision": "d283f4eb89df5fc9c28135b770891aee",
    "url": "/static/img/MINT.d283f4eb.svg"
  },
  {
    "revision": "1b5d0fd875f1710259d712b85ae99edf",
    "url": "/static/img/REMOVE_LIQUIDITY.1b5d0fd8.svg"
  },
  {
    "revision": "7cc0cbd46c45de91211d743569cd5a45",
    "url": "/static/img/TP@2x.7cc0cbd4.png"
  },
  {
    "revision": "6cd00435389a6ea1047327af66624c19",
    "url": "/static/img/TW.6cd00435.svg"
  },
  {
    "revision": "46e8589598b2f5d587eed2abe9ac0ded",
    "url": "/static/img/Tw@2x.46e85895.png"
  },
  {
    "revision": "baa2af299d882e0b92903016eb5a1695",
    "url": "/static/img/arrow-down.baa2af29.svg"
  },
  {
    "revision": "6043515c0835d727d37c518405fe2f4f",
    "url": "/static/img/arrow-dwon-1.6043515c.svg"
  },
  {
    "revision": "8c06199770ee46b59f721cf3e6b80a3f",
    "url": "/static/img/arrow-up.8c061997.svg"
  },
  {
    "revision": "1d98f3646bbfe1c1aac49fdb336ef9cf",
    "url": "/static/img/audit-bg.1d98f364.svg"
  },
  {
    "revision": "c4c7d2674f9c47b7ce1c00f7473e40ab",
    "url": "/static/img/ave-black.c4c7d267.svg"
  },
  {
    "revision": "067f81212027ae03f92f6a2e6798ab3a",
    "url": "/static/img/ave-empty.067f8121.png"
  },
  {
    "revision": "46ab30c8ea5101d664a11afd5f11a6ac",
    "url": "/static/img/ave-white.46ab30c8.png"
  },
  {
    "revision": "84b0bff8c4ed86cdb154d9f52c5ab80f",
    "url": "/static/img/aveSniperBot.84b0bff8.png"
  },
  {
    "revision": "f0904e32a11dbe177f5113591c2dcda2",
    "url": "/static/img/avedex_mobile_logo.f0904e32.svg"
  },
  {
    "revision": "a3e8d5c87535bd985301e21d7bea70bc",
    "url": "/static/img/banner-bg-light.a3e8d5c8.png"
  },
  {
    "revision": "69cd8fc36a91151f49d9524dcd08408c",
    "url": "/static/img/bg-bsc.69cd8fc3.svg"
  },
  {
    "revision": "ee7fe868586c9707ce595c8892a161a4",
    "url": "/static/img/bg-me-head.ee7fe868.svg"
  },
  {
    "revision": "03efdf33f51a936967dc12d54d0ed39e",
    "url": "/static/img/binance.03efdf33.png"
  },
  {
    "revision": "c373f8deda8c5e9714b704a9f0f25626",
    "url": "/static/img/browser.c373f8de.svg"
  },
  {
    "revision": "d44ae48ea0c2364a2dc90603efa7cced",
    "url": "/static/img/browser@2x.d44ae48e.png"
  },
  {
    "revision": "17365d094af38b969c750e860d0fba8f",
    "url": "/static/img/chainSelect.17365d09.svg"
  },
  {
    "revision": "0088d3591dc91c454a9bdc4e4d43f8ef",
    "url": "/static/img/clock.0088d359.svg"
  },
  {
    "revision": "83375cab82b0f92c0bb3b331d2b8d121",
    "url": "/static/img/connected.83375cab.svg"
  },
  {
    "revision": "3047eb60a0a68de2ebd4ed4b2c4faf0b",
    "url": "/static/img/copy.3047eb60.svg"
  },
  {
    "revision": "29d15398068512f22fcaa49087274278",
    "url": "/static/img/danbao-bg.29d15398.svg"
  },
  {
    "revision": "7c7910c609b57fecf1ee11d25fd70dab",
    "url": "/static/img/debox-lighter.7c7910c6.svg"
  },
  {
    "revision": "f62a8ff009c82552a019f799de955cac",
    "url": "/static/img/default.f62a8ff0.png"
  },
  {
    "revision": "3bfd072d7902dd19c7a0836ce6eaae37",
    "url": "/static/img/dev.3bfd072d.svg"
  },
  {
    "revision": "7b4936ac998819924aac6174790a7025",
    "url": "/static/img/dev.7b4936ac.png"
  },
  {
    "revision": "7596e1536fade55488fae9842dae2176",
    "url": "/static/img/down.7596e153.svg"
  },
  {
    "revision": "c2cec1b51d72229cadcf36edddd42bea",
    "url": "/static/img/down.c2cec1b5.svg"
  },
  {
    "revision": "255e300cd82a4fc28e37990e250a882a",
    "url": "/static/img/download.255e300c.svg"
  },
  {
    "revision": "eaaa75d7a9b7566950c439418f7b54d2",
    "url": "/static/img/drawBg.eaaa75d7.svg"
  },
  {
    "revision": "e199ea4209591af243993a67d9a929d7",
    "url": "/static/img/edit.e199ea42.svg"
  },
  {
    "revision": "ecfdc67661b8cdfc4a022ffa5cd3ab5d",
    "url": "/static/img/empty-noBalance-light.ecfdc676.svg"
  },
  {
    "revision": "c45d86af74a4117196598a7ec02942f5",
    "url": "/static/img/empty-noData-dark.c45d86af.svg"
  },
  {
    "revision": "9816939cb2282fbf2c068b9a19dffb4f",
    "url": "/static/img/empty-noData-light.9816939c.svg"
  },
  {
    "revision": "f79c66574cf08d6f342a7a6d3be55553",
    "url": "/static/img/empty-noSearch-dark.f79c6657.svg"
  },
  {
    "revision": "7e616a93755018473ab4f7610a1e6269",
    "url": "/static/img/empty-noSearch-light.7e616a93.svg"
  },
  {
    "revision": "9086edbb4890cf2b5c5171b50699bb44",
    "url": "/static/img/exchange.9086edbb.svg"
  },
  {
    "revision": "b0110bb21a56c371a30d7e688c340ed7",
    "url": "/static/img/exchange.b0110bb2.svg"
  },
  {
    "revision": "b9b1944aaee1a38e789792cdb5e5e66d",
    "url": "/static/img/fee.b9b1944a.svg"
  },
  {
    "revision": "15e201d3b416e61d98ab92bd5ec14858",
    "url": "/static/img/filter.15e201d3.svg"
  },
  {
    "revision": "171425bb992568da23a9bd428c25ce08",
    "url": "/static/img/filter.171425bb.svg"
  },
  {
    "revision": "0fb5be1540cccfbdcb5602abb76493b6",
    "url": "/static/img/filter2.0fb5be15.svg"
  },
  {
    "revision": "a68e0b7a16db0d3e61fed964d6ced6c5",
    "url": "/static/img/filter2.a68e0b7a.svg"
  },
  {
    "revision": "701924b124bc3e5c17c9bcbfbdaa8b99",
    "url": "/static/img/filter3.701924b1.svg"
  },
  {
    "revision": "fba3892733e4aa44623c4e5c1236c101",
    "url": "/static/img/fold1.fba38927.svg"
  },
  {
    "revision": "acd6a49f96e122cbfba564c77ec2c30f",
    "url": "/static/img/fold2.acd6a49f.svg"
  },
  {
    "revision": "0761d8da18eef70350116d41734fbcfc",
    "url": "/static/img/ftx.0761d8da.png"
  },
  {
    "revision": "36275cfce6fd298004bcc4f1edccf309",
    "url": "/static/img/gate.36275cfc.png"
  },
  {
    "revision": "291f9b13ab47aab65d3bf41505457664",
    "url": "/static/img/goPlus-logo.291f9b13.png"
  },
  {
    "revision": "eb6f69481482ccfe57ff8c7790dc5c57",
    "url": "/static/img/goldhouse.eb6f6948.png"
  },
  {
    "revision": "0ba4b6442c9fbcac9b9dc02556a9a4f9",
    "url": "/static/img/hideSmall.0ba4b644.svg"
  },
  {
    "revision": "4ce8025ea0ddc33eb48549af161c2ea8",
    "url": "/static/img/hideSmall2.4ce8025e.svg"
  },
  {
    "revision": "b38daf6f9007d977d84be2e5bd4ae708",
    "url": "/static/img/huobi.b38daf6f.png"
  },
  {
    "revision": "fd451fff97af9a22c9618acacd47cf46",
    "url": "/static/img/icon-default-dark.fd451fff.png"
  },
  {
    "revision": "75f6e9a0019cdd5252d2925b4a9acd52",
    "url": "/static/img/icon-default.75f6e9a0.png"
  },
  {
    "revision": "4ebadc7855a4dbc4f3f80e5e77643c32",
    "url": "/static/img/icon-inscription-default.4ebadc78.png"
  },
  {
    "revision": "4e255a2018f52f32231eddfff6b49229",
    "url": "/static/img/icon-runes-default.4e255a20.png"
  },
  {
    "revision": "fef7fac166a1927fc3f7eb9816da630e",
    "url": "/static/img/iconfont.fef7fac1.svg"
  },
  {
    "revision": "37d26075d00dec6d77c986ddeb86e079",
    "url": "/static/img/import.37d26075.svg"
  },
  {
    "revision": "5d7b85c12e27a0b3f576725c7556d69d",
    "url": "/static/img/index.5d7b85c1.svg"
  },
  {
    "revision": "ffa1b6c8461568c532b81fd3966946d7",
    "url": "/static/img/internal_transfer_in.ffa1b6c8.svg"
  },
  {
    "revision": "44ee07a1fda7251caf2be5656d8810ca",
    "url": "/static/img/internal_transfer_out.44ee07a1.svg"
  },
  {
    "revision": "d160d9e3bf6187bfe1e6a1a5d5a1e27e",
    "url": "/static/img/kucoin.d160d9e3.png"
  },
  {
    "revision": "4ed3d81e84eed2681ff883392e3a61e4",
    "url": "/static/img/link.4ed3d81e.svg"
  },
  {
    "revision": "e5369a047e3e2aceea07d1274a85246d",
    "url": "/static/img/loginBg.e5369a04.png"
  },
  {
    "revision": "3a7d87c2c63e07a3a297474c83023ae8",
    "url": "/static/img/logo.3a7d87c2.png"
  },
  {
    "revision": "687477b926b323aff15c9738ba8a31b8",
    "url": "/static/img/logo2.687477b9.svg"
  },
  {
    "revision": "14c961f95727d89cff9c4b63a0c8e740",
    "url": "/static/img/loss.14c961f9.png"
  },
  {
    "revision": "d515711e60973f66ad430252814360c9",
    "url": "/static/img/lp_hook.d515711e.svg"
  },
  {
    "revision": "98b90f1313168d459837a379596d3c69",
    "url": "/static/img/metamask.98b90f13.svg"
  },
  {
    "revision": "84ed108b5fc6365c0cdda0487e7cb97e",
    "url": "/static/img/mexc.84ed108b.png"
  },
  {
    "revision": "3c34d7864b5052658b78e49b87494e50",
    "url": "/static/img/num.3c34d786.svg"
  },
  {
    "revision": "c4b1caf2373b6be184f53bfa0778601c",
    "url": "/static/img/okx.c4b1caf2.png"
  },
  {
    "revision": "a4b467ff1c22bdb3ca2dc75643224c13",
    "url": "/static/img/open-en.a4b467ff.png"
  },
  {
    "revision": "9e56c2147a66003724a385146e24743b",
    "url": "/static/img/open-zh.9e56c214.png"
  },
  {
    "revision": "349b489d99d370e273fb8c6be095e3a7",
    "url": "/static/img/redPacket.349b489d.svg"
  },
  {
    "revision": "0e99ce47325cf5b4b6c1a8f342ea2a21",
    "url": "/static/img/right.0e99ce47.svg"
  },
  {
    "revision": "747806a0f8000d0fd8c3b228efd7b857",
    "url": "/static/img/ring.747806a0.svg"
  },
  {
    "revision": "674f11f748e30225ce09c9c09d54dcf5",
    "url": "/static/img/ring2.674f11f7.svg"
  },
  {
    "revision": "c8e67cd0cdf83732737968372113b831",
    "url": "/static/img/search.c8e67cd0.svg"
  },
  {
    "revision": "d506552e08c2cbb606583c3dcea53dec",
    "url": "/static/img/selected.d506552e.svg"
  },
  {
    "revision": "e4d6807eb7b1a2ebc86e747c447148d6",
    "url": "/static/img/swap_buy.e4d6807e.svg"
  },
  {
    "revision": "1113a2e291f3a7f2ae005793980a2ecf",
    "url": "/static/img/swap_sell.1113a2e2.svg"
  },
  {
    "revision": "79d86808627d64d33f06eac7df61636f",
    "url": "/static/img/tag16.79d86808.svg"
  },
  {
    "revision": "c503360dbc1c214ef1455a22e65ccba7",
    "url": "/static/img/tag19.c503360d.svg"
  },
  {
    "revision": "a0520e19a112b897c0e337288bae2229",
    "url": "/static/img/tag30.a0520e19.svg"
  },
  {
    "revision": "43df5e292e0d87b4a80f7862cd90cb2a",
    "url": "/static/img/tag31.43df5e29.svg"
  },
  {
    "revision": "2a527662019291be92b2976369325c77",
    "url": "/static/img/tag34.2a527662.svg"
  },
  {
    "revision": "c708626dca94145fcb9aec086052efa3",
    "url": "/static/img/tag35.c708626d.svg"
  },
  {
    "revision": "8c447832d4953abd1281226fc7d2d1a8",
    "url": "/static/img/tag36.8c447832.svg"
  },
  {
    "revision": "d4507aded686a27fbfebdd36c0976764",
    "url": "/static/img/tg.d4507ade.svg"
  },
  {
    "revision": "b24b044dc92dba7d9b66e3dff74672cf",
    "url": "/static/img/tgBot.b24b044d.svg"
  },
  {
    "revision": "1e7d220bc503d948c1dd2d7b4d0bf8c5",
    "url": "/static/img/time.1e7d220b.svg"
  },
  {
    "revision": "cf6d827902740ac39e39e0c1f9fc0eae",
    "url": "/static/img/time2.cf6d8279.svg"
  },
  {
    "revision": "f7c173ee26ad01eeb1d4be9f32c8045f",
    "url": "/static/img/tokenpocket.f7c173ee.png"
  },
  {
    "revision": "85b899042310ea39f23c1dae0650c286",
    "url": "/static/img/top.85b89904.svg"
  },
  {
    "revision": "ffa1b6c8461568c532b81fd3966946d7",
    "url": "/static/img/transfer_in.ffa1b6c8.svg"
  },
  {
    "revision": "44ee07a1fda7251caf2be5656d8810ca",
    "url": "/static/img/transfer_out.44ee07a1.svg"
  },
  {
    "revision": "114f47a050c0ec693be28e9106db958c",
    "url": "/static/img/triangle.114f47a0.svg"
  },
  {
    "revision": "41d851008b4090fca47edb4af65821b5",
    "url": "/static/img/tronlink.41d85100.png"
  },
  {
    "revision": "f95f80ba236d1d6305f61c88865f8a39",
    "url": "/static/img/trustwallet.f95f80ba.png"
  },
  {
    "revision": "e0a450a959d1e2eb0aa8199947b91942",
    "url": "/static/img/twitter.e0a450a9.svg"
  },
  {
    "revision": "45cd5bf45bf872a3b2942bcb2976f65a",
    "url": "/static/img/tx_chat_cn.45cd5bf4.png"
  },
  {
    "revision": "f7210084f389b425a3a46e515d7701e5",
    "url": "/static/img/tx_cn.f7210084.png"
  },
  {
    "revision": "afc875e91dbd017eae0bc60a08b0e514",
    "url": "/static/img/tx_en.afc875e9.png"
  },
  {
    "revision": "636d237428b84ac2572746ec25415160",
    "url": "/static/img/unlock.636d2374.png"
  },
  {
    "revision": "e0644b989bf4bc7bf6f0078710910b2f",
    "url": "/static/img/up.e0644b98.svg"
  },
  {
    "revision": "e8521ef90b2f7823494d94fde41514ef",
    "url": "/static/img/user.e8521ef9.svg"
  },
  {
    "revision": "4d4766369f451ccaf209fbaa915c5965",
    "url": "/static/img/volume-high.4d476636.svg"
  },
  {
    "revision": "349b489d99d370e273fb8c6be095e3a7",
    "url": "/static/img/wallet.349b489d.svg"
  },
  {
    "revision": "bfe95d880e18a06a58b0aa6540d14cba",
    "url": "/static/img/wallet.bfe95d88.svg"
  },
  {
    "revision": "8bf672c0b776ed7ffded40d4db53aea7",
    "url": "/static/img/wallet2.8bf672c0.svg"
  },
  {
    "revision": "b8a18c61d4ae12500897f4f907ec9f40",
    "url": "/static/img/walletTab1.b8a18c61.svg"
  },
  {
    "revision": "e09c87447e7984be39177778a5e4548a",
    "url": "/static/img/walletTab2.e09c8744.svg"
  },
  {
    "revision": "36fce5af678eba3f7e223acc18b040fb",
    "url": "/static/img/warn.36fce5af.svg"
  },
  {
    "revision": "90f84ce08cbfa2d0d182db7fbb35bcfc",
    "url": "/static/img/watch.90f84ce0.svg"
  },
  {
    "revision": "5c83ecd77101b66196d5212937f2329b",
    "url": "/static/img/watermark.5c83ecd7.png"
  },
  {
    "revision": "8009105157d6fca3b778b947a2f6f89a",
    "url": "/static/img/win.80091051.png"
  },
  {
    "revision": "f88c135c1d6f3c5672861b1d74b05c39",
    "url": "/static/img/平均成本.f88c135c.svg"
  },
  {
    "revision": "f64f0105d6fe0a8b4e355f7c95cb8c2a",
    "url": "/static/img/当前持仓.f64f0105.svg"
  },
  {
    "revision": "1a984f7d1a2605a66b43fb2313c062f5",
    "url": "/static/img/恭喜.1a984f7d.svg"
  },
  {
    "revision": "6dca0cfce8f5522da173a4586515e5b8",
    "url": "/static/img/持仓金额.6dca0cfc.svg"
  },
  {
    "revision": "db853751bb59661b559929f4a518903e",
    "url": "/static/img/盈亏情况.db853751.svg"
  },
  {
    "revision": "842e6a3aa2dda2d9fbfaa25d78692ac2",
    "url": "/static/img/邀请好友.842e6a3a.svg"
  },
  {
    "revision": "e437a3c554fc95c36bad42728e2b68ad",
    "url": "/static/img/邀请好友点击链接.e437a3c5.png"
  },
  {
    "revision": "a2781ede6c45dfccd59f",
    "url": "/static/js/Alert.b8fccfd4.js"
  },
  {
    "revision": "3648ec28504e8bd3897c",
    "url": "/static/js/Balance.3e35c2f6.js"
  },
  {
    "revision": "6f1dac2f14fe68aa6046",
    "url": "/static/js/Bownload.52c53595.js"
  },
  {
    "revision": "71d9c608bcc9835bb108",
    "url": "/static/js/Brc20.8b028954.js"
  },
  {
    "revision": "815715f5e9f610db27ab",
    "url": "/static/js/CVAirdrop.af989bde.js"
  },
  {
    "revision": "ff3f09c2b2454455286f",
    "url": "/static/js/Chat.bdc784fa.js"
  },
  {
    "revision": "6354534e0676c3d3b226",
    "url": "/static/js/ChatBanned.1c674043.js"
  },
  {
    "revision": "80fd096549012f511c8e",
    "url": "/static/js/ChatBurn.736a6ec0.js"
  },
  {
    "revision": "b9d3ba752e2ebb12d514",
    "url": "/static/js/ChatIndex.1f4669ab.js"
  },
  {
    "revision": "3ab004fcb041cc4fd51f",
    "url": "/static/js/ChatNewPayment.92ee94f9.js"
  },
  {
    "revision": "c752b26426b8883eed48",
    "url": "/static/js/ChatOfficial.1c187200.js"
  },
  {
    "revision": "48542e4bf5bd796a1577",
    "url": "/static/js/ChatPenalty.f34de1af.js"
  },
  {
    "revision": "c38a46ef114b30b6d438",
    "url": "/static/js/ChatSet.721463e5.js"
  },
  {
    "revision": "5f2d2e076750b3bd34b5",
    "url": "/static/js/ChatTop.96523e90.js"
  },
  {
    "revision": "1a49df09446764497362",
    "url": "/static/js/Chat~ChatTop.9836a9d9.js"
  },
  {
    "revision": "b2f74db4eeb8e256c286",
    "url": "/static/js/Check.f8bf0580.js"
  },
  {
    "revision": "2c7dc569fabb921becc1",
    "url": "/static/js/Connect.42cfbfe8.js"
  },
  {
    "revision": "cdd080abac81355252e9",
    "url": "/static/js/Discover.d2ff1d52.js"
  },
  {
    "revision": "dbfb18ec61cf31b823b1",
    "url": "/static/js/Evm.0d64d192.js"
  },
  {
    "revision": "97156c90daca05536956",
    "url": "/static/js/Fav.e47604d5.js"
  },
  {
    "revision": "a38951520e75bbc72437",
    "url": "/static/js/FavoriteManage.ef33205c.js"
  },
  {
    "revision": "e186001a2c2a991c40af",
    "url": "/static/js/Gas.c5e4f4cb.js"
  },
  {
    "revision": "061b58df85badc927e99",
    "url": "/static/js/Home.a853b698.js"
  },
  {
    "revision": "9eae1c024f2f321eda45",
    "url": "/static/js/Inscription.0c8ea33c.js"
  },
  {
    "revision": "6c22db96184564069125",
    "url": "/static/js/Invitation.c0932b29.js"
  },
  {
    "revision": "ded15d9ecdd96d6ea4d4",
    "url": "/static/js/Login.a0923884.js"
  },
  {
    "revision": "2dcc552f38df160e2fb3",
    "url": "/static/js/Lost.f5349902.js"
  },
  {
    "revision": "14f87346d050155ed027",
    "url": "/static/js/Market.e5f7e4a4.js"
  },
  {
    "revision": "0ae9e9307130591ad243",
    "url": "/static/js/Me.3419f5eb.js"
  },
  {
    "revision": "59752582401afc36dabc",
    "url": "/static/js/MyChats.1d3f3181.js"
  },
  {
    "revision": "f7427158066b77e7115d",
    "url": "/static/js/NFT.79d0a609.js"
  },
  {
    "revision": "e8619bbae9e72457fa57",
    "url": "/static/js/Notice.2d65e127.js"
  },
  {
    "revision": "095c754cb549668c9f07",
    "url": "/static/js/OfficialVerification.eb40e781.js"
  },
  {
    "revision": "8aca776a180e45121f52",
    "url": "/static/js/Perp.2a9c5969.js"
  },
  {
    "revision": "956f3b92ec0d2b17a443",
    "url": "/static/js/Plate.0468cde5.js"
  },
  {
    "revision": "d3fc20d8973150204506",
    "url": "/static/js/Pool.59746661.js"
  },
  {
    "revision": "167e0204cc04d682ebdc",
    "url": "/static/js/RedCreate.dec44e07.js"
  },
  {
    "revision": "160803ad5aeaf30956b0",
    "url": "/static/js/RedRecord.9e0dae38.js"
  },
  {
    "revision": "01da6cc13069418f6c1d",
    "url": "/static/js/Runes.fc53e46e.js"
  },
  {
    "revision": "e89d1554d847eeacb327",
    "url": "/static/js/ShareLink.bf801120.js"
  },
  {
    "revision": "d4d29261c95f6e9e62a2",
    "url": "/static/js/Token.b97010ef.js"
  },
  {
    "revision": "435e3886be97847b8552",
    "url": "/static/js/UserInfo.0fe74845.js"
  },
  {
    "revision": "cd366f84d7b0b4562882",
    "url": "/static/js/Wallet.b74358cd.js"
  },
  {
    "revision": "be8a3239a639da8fb7c3",
    "url": "/static/js/WalletDetail.1f02922e.js"
  },
  {
    "revision": "7faaecaa7c708d2fb91a",
    "url": "/static/js/app.f174a606.js"
  },
  {
    "revision": "21f900b68a936f475d90",
    "url": "/static/js/chunk-44f023b1.68e1e207.js"
  },
  {
    "revision": "03faef7f8cbd23cb0802",
    "url": "/static/js/chunk-4629509a.a28e3a25.js"
  },
  {
    "revision": "2a8d14332a6ab51b9af9",
    "url": "/static/js/chunk-commons.7aa296fb.js"
  },
  {
    "revision": "0d4502405849dbe30a18",
    "url": "/static/js/chunk-d7d9e2e2.694f1eeb.js"
  },
  {
    "revision": "99c1d1134f011eb3ade5",
    "url": "/static/js/chunk-echarts.c7877cab.js"
  },
  {
    "revision": "2c535022d5ca8f9fbf74",
    "url": "/static/js/chunk-fe267f12.a44790ba.js"
  },
  {
    "revision": "cb4abbb7a4c21e0ca69f",
    "url": "/static/js/chunk-libs.14131fb4.js"
  },
  {
    "revision": "caca61b47349ec0636f6",
    "url": "/static/js/chunk-vant.a8ffce87.js"
  },
  {
    "revision": "ed883dd4b7a3a8af922a",
    "url": "/static/js/runtime.5b168be6.js"
  },
  {
    "revision": "fdec508fd0b2d33f3fad",
    "url": "/static/js/vendors~Brc20.495ba1fe.js"
  },
  {
    "revision": "cad697cab4b93ae45e5e",
    "url": "/static/js/vendors~Brc20~Chat~ChatTop~Home~NFT~Token.11833202.js"
  },
  {
    "revision": "5fe2d36316b142aa3fc0",
    "url": "/static/js/vendors~Brc20~NFT~Perp.53f6e23d.js"
  },
  {
    "revision": "4a5e95145eadda96c091",
    "url": "/static/js/vendors~ChatPenalty.46e8960b.js"
  },
  {
    "revision": "5523f931fd9f39f41220",
    "url": "/static/js/vendors~ChatSet~UserInfo.1673f313.js"
  },
  {
    "revision": "7e703adec6f8ff53da2e",
    "url": "/static/js/vendors~Chat~ChatTop.c136ef17.js"
  },
  {
    "revision": "d15fadfac3096455d60b",
    "url": "/static/js/vendors~Check.46bc530c.js"
  },
  {
    "revision": "b1d24fc77a424867ed71",
    "url": "/static/js/vendors~Home~Market~Token~WalletDetail~whaleTracking.ea866faf.js"
  },
  {
    "revision": "d60d3442464046a59a2f",
    "url": "/static/js/vendors~Market.173592d0.js"
  },
  {
    "revision": "17d6f684fcd46225235d",
    "url": "/static/js/vendors~WalletDetail.315defcd.js"
  },
  {
    "revision": "a9dee7b0be5a20b72315",
    "url": "/static/js/whaleTracking.974c3495.js"
  },
  {
    "revision": "a0b57e2e39412c9b33b7a3ebbcfea7ae",
    "url": "/vemachine.js"
  }
]);